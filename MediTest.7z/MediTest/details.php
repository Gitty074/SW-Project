  <?php include 'connect.php';
  if (session_status() == PHP_SESSION_NONE) 
  {
    session_start();
  }
  if(!$_SESSION['LoggedIn'])
      {
        header("Location: http://localhost/meditest/login.php");
      } 
  ?> 
  <!DOCTYPE html>
  <html lang="en" class="no-js"> 


  <html>
  <head>
    <title>Results</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <!-- Search -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/main.css">
    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script type="text/javascript" src="js/moment.js"></script>
    <script type="text/javascript" src="js/collapse.js"></script>
    <script type="text/javascript" src="js/transition.js"></script>
    <script type="text/javascript" src="bootstrap-datetimepicker.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
      .container { margin-top: 20px; }
      .mb20 { margin-bottom: 20px; } 

      hgroup { padding-left: 15px; border-bottom: 1px solid #ccc; }
      hgroup h1 { font: 500 normal 1.725em "Open Sans",Arial,Verdana,sans-serif; color: #000; margin-top: 0; line-height: 1.15; }
      hgroup h2.lead { font: normal normal 1.325em "Open Sans",Arial,Verdana,sans-serif; color: #000; margin: 0; padding-bottom: 10px; }
    </style>
  </head>
  <body>

    <div class="container">
      <header id="navigation" class="navbar-inverse navbar-fixed-top animated-header"  style="background-color: #003cb3" >
        <div class="container">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
              <a href="index.php"><img src="img/logo.png"></a>  
            <!-- /logo -->
          </div>

          <!-- main nav -->
          <nav class="collapse navbar-collapse navbar-right" role="navigation">
            <ul id="nav" class="nav navbar-nav">
               <li>
                <?php if(isset($_SESSION['Username'])):?>
                  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown"><?php echo $_SESSION['Username'] ?>
                  <span class="caret"></span></button>
                  <ul class="dropdown-menu">
                    <li><a href="history.php" class="external">Booking History</a></li>
                    <li><a href="feedback.php" class="external"> Give Feedback</a></li>
                    <li><a href="logout.php" class="external">Logout</a></li>
                  </ul>
                  <?php else: ?>
                <li><a href ="login.php" class="external">Login</a></li>
                 <?php endif; ?>
            </ul>
          </nav>
          <!-- /main nav -->

        </div>
      </header>
      <br><br><br><br><br><br><br>
     <div class="container">
        <div class="row">
          <div class='col-sm-8'>
            </div>
            <?php
            $lab_name = $_GET['lab_name'];
            echo "<h2>Review test at ".$lab_name."</h2>";
              ?>

              <br><br><br><br><br>
        <!--Calendar -->
              <div>
                <form method="post" action="submission.php">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Lab Visiting Date</th>
                        <th>Lab Visiting Time</th>
                        <th>Test Name</th>
                        <th>Price</th>
                        <th>Lab Name</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                      <td>
                        <div class="col-md-5">
                        <div class="form-group">
                          <div class='input-group date'>
                            <input type='text' class="form-control" id="datepicker" name="datepicker" />
                              <span class="input-group-addon">
                                <span class="glyphicon glyphicon-calendar"></span>
                              </span>
                              </div>
                            </div>
                        </div> 
                  </div>
                  <script>
                    $( function() {
                      $( "#datepicker" ).datepicker();
                    } );
                  </script>
                  </td>
                  <td>
                      <select name="timepicker" required="required">        
                          <option value="10:00am">10:00am</option>
                          <option value="11:00am">11:00am</option>
                          <option value="12:00pm">12:00pm</option>
                          <option value="1:00pm">1:00pm</option>
                          <option value="1:00pm">2:00pm</option>
                          <option value="1:00pm">3:00pm</option>
                          <option value="1:00pm">4:00pm</option>
                          <option value="1:00pm">5:00pm</option>
                          <option value="1:00pm">6:00pm</option>
                       </select>
                      </td>
                      <td>
                        <?php echo $_GET['test_name'];$_SESSION['test_name'] =$_GET['test_name']; ?>
                      </td>
                      <td>
                        <?php echo $_GET['test_price'];$_SESSION['test_price'] =$_GET['test_price'];?>
                      </td>
                      <td>
                      <?php echo $_GET['lab_name'];$_SESSION['lab_name'] =$_GET['lab_name'];?>
                      </td>
                      </tr>
                    </tbody>
                  </table>
                  <br><br>
                  <button type="submit" class="btn btn-primary">Confirm</button>
                </form>
              </div>
        </div>
      </div>
      <div class="table">
      <h3>What People Are Saying About It:</h3>
      <table class="table table-bordered">
        <?php
          $sql =
           "SELECT user_accounts.user_id,user_accounts.user_name,test.test_name,labs.lab_name,feedback.hospitality,feedback.facilty,feedback.overall,feedback.comment FROM `feedback` NATURAL JOIN `user_accounts` NATURAL JOIN `test` NATURAL JOIN `labs` 
            WHERE test.test_name='".$_GET['test_name']."'".
            "AND labs.lab_name='".$_SESSION['lab_name']."'";
          $query_to = mysqli_query($conn, $sql);
          $result = mysqli_query($conn,$sql);
          $count = mysqli_num_rows($query_to);
          if($count==0)
            echo "<h3>No feedback yet given.</h3>";
          else
          {
            while($row = mysqli_fetch_assoc($result))
            {
              echo "<tr><td>".$row['user_name']."</td><br>".
                    "<td>".$row['comment']."</td>".
                    "<td>Hospitality: ".$row['hospitality']."/5</td>".
                    "<td>Facility: ".$row['facilty']."/5</td>".
                    "<td>Overall Points: ".$row['overall']."/5</td>";
            }
          }
        ?>
      </table>
     </div>
     </div>
    </body>
    </html>

