
<!DOCTYPE html>
<!--[if lt IE 7]>      <html lang="en" class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html lang="en" class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html lang="en" class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
  <?php include 'connect.php'; 
    if (session_status() == PHP_SESSION_NONE)
    		session_start();
    	//if(isset($_SESSION['UserID']))
    		//echo $_SESSION['UserID'];
     ?>
     
<head>
	<!-- meta character set -->
	<meta charset="utf-8">
	<!-- Always force latest IE rendering engine or request Chrome Frame -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>MediTest:Online Test Booking Service</title>		
	<!-- Mobile Specific Meta -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
		<!-- CSS
		================================================== -->
		
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
		
		<!-- Fontawesome Icon font -->
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- bootstrap.min -->
		<link rel="stylesheet" href="css/jquery.fancybox.css">
		<!-- bootstrap.min -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- bootstrap.min -->
		<link rel="stylesheet" href="css/owl.carousel.css">
		<!-- bootstrap.min -->
		<link rel="stylesheet" href="css/slit-slider.css">
		<!-- bootstrap.min -->
		<link rel="stylesheet" href="css/animate.css">
		<!-- Main Stylesheet -->
		<link rel="stylesheet" href="css/main.css">
		<!-- Search -->
		<link rel="stylesheet" href="css/style.css">
		<!--    bootstrap for search    -->
		
		<!--    ends    -->
		<!-- <link rel="stylesheet" href="css/search.css"> -->
		<!-- Modernizer Script for old Browsers -->
		<script src="js/modernizr-2.6.2.min.js"></script>
		 <script type="text/javascript">
        	function showResult(str) {
  if (str.length==0) {
    document.getElementById("livesearch").innerHTML="";
    document.getElementById("livesearch").style.border="0px";
    return;
  }
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("livesearch").innerHTML=this.responseText;
      document.getElementById("livesearch").style.border="1px solid #A5ACB2";
    }
  }
  xmlhttp.open("GET","livesearch.php?q="+str,true);
  xmlhttp.send();
}
        </script>
	</head>
	
	<body id="body">

		<!-- preloader -->
		<div id="preloader">
			<div class="loder-box">
				<div class="battery"></div>
			</div>
		</div>
		<!-- end preloader -->
		
        <!--
        Fixed Navigation
        ==================================== -->
        <header id="navigation" class="navbar-inverse navbar-fixed-top animated-header">
        	<div class="container">
        		<div class="navbar-header">
           				 <a href="index.php"><img src="img/logo.png" alt="MediTest"></a>
        		</div>

        		<!-- main nav -->
        		<nav class="collapse navbar-collapse navbar-right" role="navigation">
        			<ul id="nav" class="nav navbar-nav">
        				<li><a href="#body">Home</a></li>
        				<li><a href="#service">Service</a></li>
        				<li><a href="#testimonials">Testimonial</a></li>
        				<li><a href="#aboutus">About Us</a></li>
        				<li><a href="#contact">Contact</a></li>
        				<li><?php if(isset($_SESSION['Username'])):?>
        				<!--<a href="logout.php" class="external">logout</a>-->
        					<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown"><?php echo $_SESSION['Username'] ?>
						    <span class="caret"></span></button>
						    <ul class="dropdown-menu">
						      <li><a href="history.php" class="external">Booking History</a></li>
						      <li><a href="feedback.php" class="external"> Give Feedback</a></li>
						      <li><a href="logout.php" class="external">Logout</a></li>
						    </ul>
        				</li> <?php else: ?>
			            <li><a href="login.php" class="external">login</a></li><?php endif; ?>
        			</ul>
        		</nav>
        		
        		<!-- /main nav -->
        		
        	</div>
        </header>
        <!--
        End Fixed Navigation
        ==================================== -->
        
        <main class="site-content" role="main">
        	
        <!--
        Home Slider
        ==================================== -->
        
        <section id="home-slider" >
        	<div id="slider" class="sl-slider-wrapper">

        		<div class="sl-slider">
        			
        			<div class="sl-slide" data-orientation="horizontal" data-slice1-rotation="-25" data-slice2-rotation="-25" data-slice1-scale="2" data-slice2-scale="2">

        				<div class="bg-img bg-img-1"></div>

        				<div class="slide-caption">
        					<div class="caption-content" >
        						<h2 class="wow animated bounceInLeft">Welcome To MediTest</h2>
        						<span class="wow animated bounceInRight">Search for tests according to your need</span>
        						<!-- SEARCH PORTION STARTS -->
        						<div id="searchLbl" >
        							<link rel="stylesheet" href="css/style.css"> 
        							
        							<form action="result.php" id="radios" method="post" class="animated fadeInDown" onkeyup="showResult(this.value)>
        								<i id="srcI" class="fa fa-fw fa-search"></i>
        								<input id="searchInput" type="text" name="search" placeholder="Search For Tests and Labs">
        								<div class="btn-group btn-group-horizontal" data-toggle="buttons">
        									<label class="btn active">
        										<input type="radio" name='radio' value="test_name" checked><i class="fa fa-circle-o fa-2x"></i><i class="fa fa-dot-circle-o fa-2x"></i>
        										 <span style="color: white">Test Name</span>
        									</label>
        									<label class="btn active">
        										<input type="radio" name='radio' value="lab_name"><i class="fa fa-circle-o fa-2x"></i><i class="fa fa-dot-circle-o fa-2x"></i>
        										 <span style="color: white">Lab Name</span>
        									</label>
        									<label class="btn active">
        										<input type="radio" name='radio' value="lab_location"><i class="fa fa-circle-o fa-2x"></i><i class="fa fa-dot-circle-o fa-2x"></i>
        										 <span style="color: white">Location</span>
        									</label>
        								</div>
        								<div class="radio">
									         Sort Results By:
									            <label class="radio-inline" style="color: white;">
									            <input type="radio" value="plth" name="sort" checked="checked">Price: Low-to-High</label>
									            <label class="radio-inline" style="color: white;">
									            <input type="radio" value="phtl" name="sort">Price: High-to-Low</label>
									        </div>
        							</form>
        						</div>

        						<!-- SEARCH PORTION ENDS -->
        					</div>
        				</div>
        				
        			</div><!-- /slider-wrapper -->
        		</section>
        		
        <!--
        End Home SliderEnd
        ==================================== -->
        
        <!-- about section -->
        <section id="about" >
        	<div class="container">
        		<div class="row">
        			<div class="col-md-4 wow animated fadeInLeft">
        				<div class="recent-works">
        					<h3>Recent Works</h3>
        					<div id="works">
        						<div class="work-item">
        							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. <br> <br> There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
        						</div>
        						<div class="work-item">
        							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. <br><br> There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
        						</div>
        						<div class="work-item">
        							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. <br><br> There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
        						</div>
        					</div>
        				</div>
        			</div>
        			<div class="col-md-7 col-md-offset-1 wow animated fadeInRight">
        				<div class="welcome-block">
        					<h3>Welcome To Our Site</h3>								
        					<div class="message-body">
        						<img src="img/member-1.jpg" class="pull-left" alt="member">
        						<p>Meditest is a wonderful website to search for medical tests in Dhaka according to your budget and preferred location. </p>
        					</div>
        					<a href="#" class="btn btn-border btn-effect pull-right">Read More</a>
        				</div>
        			</div>
        		</div>
        	</div>
        </section>
        <!-- end about section -->
        
        
        <!-- Service section -->
        <section id="service">
        	<div class="container">
        		<div class="row">
        			
        			<div class="sec-title text-center">
        				<h2 class="wow animated bounceInLeft">Service</h2>
        				<p class="wow animated bounceInRight">The Key Features of Our Site</p>
        			</div>
        			
        			<div class="col-md-6 col-sm-6 col-xs-12 text-center wow animated zoomIn">
        				<div class="service-item">
        					<div class="service-icon">
        						<i class="fa fa-home fa-3x"></i>
        					</div>
        					<h3>Online Booking</h3>
        					<p>We have a simple yet effective and hassle free online booking system for your convenience so that you can book tests easily. </p>
        				</div>
        			</div>
        			
        			<div class="col-md-6 col-sm-6 col-xs-12 text-center wow animated zoomIn" data-wow-delay="0.3s">
        				<div class="service-item">
        					<div class="service-icon">
        						<i class="fa fa-tasks fa-3x"></i>
        					</div>
        					<h3>Rich Database</h3>
        					<p>Covers hospitals and clinics around Dhaka</p>
        				</div>
        			</div>
        	
						
					</div>
				</div>
			</section>
			<!-- end Service section -->
			
			
			
			<!-- Testimonial section -->
			<section id="testimonials" class="parallax">
				<div class="overlay">
					<div class="container">
						<div class="row">
							
							<div class="sec-title text-center white wow animated fadeInDown">
								<h2>What people say</h2>
							</div>
							
							<div id="testimonial" class=" wow animated fadeInUp">
								<div class="testimonial-item text-center">
									<img src="img/member-1.jpg" alt="Our Clients">
									<div class="clearfix">
										<span>Doctor Strange</span>
										<p>The website was pretty helpful.It is easy to use and user-friendly.I would definitely recommend it. </p>
									</div>
								</div>
								<div class="testimonial-item text-center">
									<img src="img/member-1.jpg" alt="Our Clients">
									<div class="clearfix">
										<span>Doctor Who</span>
										<p>The website was pretty helpful.It is easy to use and user-friendly.I would definitely recommend it. </p>
									</div>
								</div>
							</div>
							
						</div>
					</div>
				</div>
			</section>
			<!-- end Testimonial section -->
			
			<!-- Price section -->
			<section id="aboutus">
				<div class="container">
					<div class="row">
						
						<div class="sec-title text-center wow animated fadeInDown">
							<h2>About Me</h2>
						</div>
						
						<div class="row">
							<div class="col-sm-12" align="center">
								<div class="team-member">
									<img src="img/team/4.jpg" class="img-responsive img-circle img-center" alt="">
									<h4>Mirza Farhan</h4>
									<p class="text-muted">Lead Designer and Programmer</p>
									<ul class="list-inline social-buttons">
										<li><a href="#"><i class="fa fa-twitter"></i></a>
										</li>
										<li><a href="#"><i class="fa fa-facebook"></i></a>
										</li>
										<li><a href="#"><i class="fa fa-linkedin"></i></a>
										</li>
									</ul>
								</div>
							</div>
							</div>
							
						</div>
					</div>
				</section>
				<!-- end Price section -->
				
				<!-- Social section -->
				<section id="social" class="parallax">
					<div class="overlay">
						<div class="container">
							<div class="row">
								
								<div class="sec-title text-center white wow animated fadeInDown">
									<h2>FOLLOW US</h2>
								</div>
								
								<ul class="social-button">
									<li class="wow animated zoomIn"><a href="#"><i class="fa fa-thumbs-up fa-2x"></i></a></li>
									<li class="wow animated zoomIn" data-wow-delay="0.3s"><a href="#"><i class="fa fa-twitter fa-2x"></i></a></li>
									<li class="wow animated zoomIn" data-wow-delay="0.6s"><a href="#"><i class="fa fa-dribbble fa-2x"></i></a></li>							
								</ul>
								
							</div>
						</div>
					</div>
				</section>
				<!-- end Social section -->
				
				<!-- Contact section -->
				<section id="contact" >
					<div class="container">
						<div class="row">
							
							<div class="sec-title text-center wow animated fadeInDown">
								<h2>Contact</h2>
								<p>Leave a Message</p>
							</div>
							
							
							<div class="col-md-7 contact-form wow animated fadeInLeft">
								<form action="mail.php" method="post">
									<div class="input-field">
										<input type="text" name="name" class="form-control" placeholder="Your Name...">
									</div>
									<div class="input-field">
										<input type="email" name="email" class="form-control" placeholder="Your Email...">
									</div>
									<div class="input-field">
										<input type="text" name="subject" class="form-control" placeholder="Subject...">
									</div>
									<div class="input-field">
										<textarea name="message" class="form-control" placeholder="Messages..."></textarea>
									</div>
									<button type="submit" id="submit" class="btn btn-blue btn-effect">Send</button>
								</form>
							</div>
							
							<div class="col-md-5 wow animated fadeInRight">
								<address class="contact-details">
									<h3>Contact Us</h3>						
									<p><i class="fa fa-pencil"></i>MediTest Limited<span>PO Box 1216</span> <span>Dhanmondhi 15, Sathmasjid Road </span><span>Dhaka</span></p><br>
									<p><i class="fa fa-phone"></i>Phone: (415) 124-5678 </p>
									<p><i class="fa fa-envelope"></i>meditest@gg.com</p>
								</address>
							</div>
							
						</div>
					</div>
				</section>
				<!-- end Contact section -->
				
			</main>
			
			<footer id="footer">
				<div class="container">
					<div class="row text-center">
						<div class="footer-content">
							<div class="wow animated fadeInDown">
								<p>newsletter signup</p>
								<p>Thanks</p>
							</div>
							<form action="#" method="post" class="subscribe-form wow animated fadeInUp">
								<div class="input-field">
									<input type="email" class="subscribe form-control" placeholder="Enter Your Email...">
									<button type="submit" class="submit-icon">
										<i class="fa fa-paper-plane fa-lg"></i>
									</button>
								</div>
							</form>
							<div class="footer-social">
								<ul>
									<li class="wow animated zoomIn"><a href="#"><i class="fa fa-thumbs-up fa-3x"></i></a></li>
									<li class="wow animated zoomIn" data-wow-delay="0.3s"><a href="#"><i class="fa fa-twitter fa-3x"></i></a></li>
									<li class="wow animated zoomIn" data-wow-delay="0.6s"><a href="#"><i class="fa fa-skype fa-3x"></i></a></li>
									<li class="wow animated zoomIn" data-wow-delay="0.9s"><a href="#"><i class="fa fa-dribbble fa-3x"></i></a></li>
									<li class="wow animated zoomIn" data-wow-delay="1.2s"><a href="#"><i class="fa fa-youtube fa-3x"></i></a></li>
								</ul>
							</div>
							
							<!-- <p>Copyright &copy; 2014-2015 Design and Developed By<a href="http://www.themefisher.com">Themefisher</a> </p> -->
						</div>
					</div>
				</div>
			</footer>
			<!-- PHP PLUGIN -->
			

			<!-- PHP PLUGIN END -->
		<!-- Essential jQuery Plugins
		================================================== -->
		a
		<script src="js/search.js"></script>
		<!-- Main jQuery -->
		<script src="js/jquery-1.11.1.min.js"></script>
		<!-- Twitter Bootstrap -->
		<script src="js/bootstrap.min.js"></script>
		<!-- Single Page Nav -->
		<script src="js/jquery.singlePageNav.min.js"></script>
		<!-- jquery.fancybox.pack -->
		<script src="js/jquery.fancybox.pack.js"></script>
		<!-- Google Map API -->
		<script src="http://maps.google.com/maps/api/js?sensor=false"></script>
		<!-- Owl Carousel -->
		<script src="js/owl.carousel.min.js"></script>
		<!-- jquery easing -->
		<script src="js/jquery.easing.min.js"></script>
		<!-- Fullscreen slider -->
		<script src="js/jquery.slitslider.js"></script>
		<script src="js/jquery.ba-cond.min.js"></script>
		<!-- onscroll animation -->
		<script src="js/wow.min.js"></script>
		<!-- Custom Functions -->
		<script src="js/main.js"></script>
	</body>
	</html>