<?php
	require 'connect.php';
	session_start();
	$user_id = $_SESSION['UserID'];
	if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		  $lab_id = $_POST['lab_id'];
		  $test_id = $_POST['test_id'];
          $selected_hos_point = $_POST['hos_point'];
          $selected_fac_point = $_POST['fac_point'];
          $selected_ov_point = $_POST['ov_point'];
          $comment = $_POST['comment'];
	}

	$addSQL = "INSERT INTO `feedback`(`user_id`, `lab_id`, `test_id`, `hospitality`, `facilty`, `overall`, `comment`) VALUES ('$user_id','$lab_id','$test_id','$selected_hos_point','$selected_fac_point','$selected_ov_point','$comment')";
	if (mysqli_query($conn, $addSQL)) 
	{
    	echo "Information added successfully";
   		echo "<button onclick=\"window.location.href='../meditest/index.php'\">Continue</button>\n";

	} else {
    echo "Error adding to database: " . mysqli_error($conn);
   // echo "<button onclick=\"window.location.href='../pages/admin.php'\">Continue</button>\n";
    }
    mysqli_close($conn);

?>