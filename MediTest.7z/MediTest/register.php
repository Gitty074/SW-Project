<?php
	require 'connect.php';
	if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$fullname = $_POST['fullname'];
		$username = $_POST['username'];
		$email = $_POST['email'];
		$phone = $_POST['phone'];
		$password = $_POST['password'];
		$cpassword = $_POST['confirm-password'];
	}
	if($password==$cpassword)
	{
		$addSQL = "INSERT INTO `user_accounts`(`full_name`,`user_name`,`user_email`, `user_phone`, `user_password`)
		 	VALUES('$fullname','$username','$email','$phone','$password') ";
		if (mysqli_query($conn, $addSQL)) {
	    echo "<h3>"."Registered successfully"."</h3>";
	    echo "<button onclick=\"window.location.href='../meditest/index.php'\">Continue</button>\n";
		} else {
		    echo "Error adding to database: " . mysqli_error($conn);
		   	echo "<button onclick=\"window.location.href='http://localhost/meditest/login.php'\">Continue</button>\n";
		    }
		    mysqli_close($conn);
	}
	else
	{
		echo '<script language="javascript">';
		echo 'alert("Passwords do not match.Please enter again")';
		echo '</script>';
		echo "<button onclick=\"window.location.href='../meditest/login.php'\">Continue</button>\n";
	}
	
?>