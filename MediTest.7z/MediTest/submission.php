  <?php include 'connect.php';
  if (session_status() == PHP_SESSION_NONE) {
    session_start();
    } 
  ?> 
  <!DOCTYPE html>
  <html lang="en" class="no-js"> 


  <html>
  <head>
    <title>Results</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <!-- Search -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/main.css">
    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script type="text/javascript" src="js/moment.js"></script>
    <script type="text/javascript" src="js/collapse.js"></script>
    <script type="text/javascript" src="js/transition.js"></script>
    <script type="text/javascript" src="bootstrap-datetimepicker.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
      .container { margin-top: 20px; }
      .mb20 { margin-bottom: 20px; } 

      hgroup { padding-left: 15px; border-bottom: 1px solid #ccc; }
      hgroup h1 { font: 500 normal 1.725em "Open Sans",Arial,Verdana,sans-serif; color: #000; margin-top: 0; line-height: 1.15; }
      hgroup h2.lead { font: normal normal 1.325em "Open Sans",Arial,Verdana,sans-serif; color: #000; margin: 0; padding-bottom: 10px; }
    </style>
  </head>
  <body>

    <div class="container">
      <header id="navigation" class="navbar-inverse navbar-fixed-top animated-header"  style="background-color: #003cb3" >
        <div class="container">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
              <a href="index.php"><img src="img/logo.png"></a>  
            <!-- /logo -->
          </div>

          <!-- main nav -->
          <nav class="collapse navbar-collapse navbar-right" role="navigation">
            <ul id="nav" class="nav navbar-nav">
               <li>
                <?php if(isset($_SESSION['Username'])):?>
                  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown"><?php echo $_SESSION['Username'] ?>
                  <span class="caret"></span></button>
                  <ul class="dropdown-menu">
                    <li><a href="history.php" class="external">Booking History</a></li>
                    <li><a href="feedback.php" class="external"> Give Feedback</a></li>
                    <li><a href="logout.php" class="external">Logout</a></li>
                  </ul>
                  <?php else: ?>
                <li><a href ="login.php" class="external">Login</a></li>
                 <?php endif; ?>
            </ul>
          </nav>
          <!-- /main nav -->

        </div>
      </header>
      <br><br><br><br><br><br><br>
        <form method="post" action="final.php">
          <div class="form-group">
            <label for="name">Patient Name:</label>
            <input type="text" class="form-control" id="name" name="name" required="required">
          </div>
          <div class="form-group">

            <label for="gender">Patient Gender:</label>
            <label class="radio-inline" style="color: black;">
            <input type="radio" value="male" name="gender" checked="checked">Male</label>
            <label class="radio-inline" style="color: black;">
            <input type="radio" value="female" name="gender">Female</label>
          </div><br>
          <div class="form-group">
            <label for="adress">Patient Address:</label>
            <input type="text" class="form-control" id="adress" name="address" required="required">
          </div>
          <div class="form-group">
            <label for="phone">Patient Phone:</label>
            <input type="text" class="form-control" id="phone" name="phone" required="required">
          </div>
          <div class="form-group">
            <label for="phone">Patient Email:</label>
            <input type="text" class="form-control" id="email" name="email">
          </div>
          <br><br>
          <label for="test_name">Test:</label>
          <?php echo $_SESSION['test_name'] ?><br>
          <label for="test_name">Lab:</label>
          <?php echo $_SESSION['lab_name'] ?><br>
          <label for="test_price">Total Cost:</label>
          <?php echo $_SESSION['test_price'] ?> Taka<br>
          <label for="test_date">Appointment Date:</label>
          <?php echo $_POST['datepicker']; $_SESSION['datepicker'] = $_POST['datepicker']; ?><br>
          <label for="test_time">Appointment Time</label>
          <?php echo $_POST['timepicker'];$_SESSION['timepicker'] = $_POST['timepicker']; ?><br>
          <button type="submit" class="btn btn-default">Submit</button>
        </form> 
    </body>
    </html>

