<?php include 'connect.php'; 
    if (session_status() == PHP_SESSION_NONE) {
          session_start();}
          ?>
            
  <!DOCTYPE html>
  <html lang="en" class="no-js">
  <html>
  <head>
    <title>Results</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <!-- Search -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/main.css">
    <style>


      .container { margin-top: 20px; }
      .mb20 { margin-bottom: 20px; } 

      hgroup { padding-left: 15px; border-bottom: 1px solid #ccc; }
      hgroup h1 { font: 500 normal 1.725em "Open Sans",Arial,Verdana,sans-serif; color: #000; margin-top: 0; line-height: 1.15; }
      hgroup h2.lead { font: normal normal 1.325em "Open Sans",Arial,Verdana,sans-serif; color: #000; margin: 0; padding-bottom: 10px; }

      .search-result .thumbnail { border-radius: 0 !important; }
      .search-result:first-child { margin-top: 0 !important; }
      .search-result { margin-top: 20px; }
      .search-result .col-md-2 { border-right: 1px dotted #ccc; min-height: 140px; }
      .search-result ul { padding-left: 0 !important; list-style: none;  }
      .search-result ul li { font: 400 normal 1em "Open Sans",Arial,Verdana,sans-serif;  line-height: 30px; }
      .search-result ul li i { padding-right: 5px; }
      .search-result .col-md-7 { position: relative; }
      .search-result h3 { font: 500 normal .675em "Open Sans",Arial,Verdana,sans-serif; margin-top: 0 !important; margin-bottom: 10px !important; }
      .search-result h3 > a, .search-result i { color: #248dc1 !important; }
      .search-result p { font: normal normal 1.125em "Open Sans",Arial,Verdana,sans-serif; } 
      /*                .search-result span.plus { position: absolute; right: 0; top: 126px; }*/
      .meta-search li.plus a { background-color: #248dc1; color: white; text-decoration: none; padding: 5px 5px 3px 5px; }
      .meta-search li.plus a:hover { background-color: #414141; }
      .meta-search li.plus a i { color: #fff !important; }
      .meta-search li.border { display: block; width: 97%; margin: 0 15px; border-bottom: 1px dotted #ccc; }
    </style>
  </head>
  <body>

    <div class="container">
      <header id="navigation" class="navbar-inverse navbar-fixed-top animated-header"  style="background-color: #003cb3" >
        <div class="container">
          <div class="navbar-header">
            <!-- responsive nav button -->
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
              <a href="index.php"><img src="img/logo.png"></a>  
            <!-- /logo -->
          </div>

          <!-- main nav -->
          <nav class="collapse navbar-collapse navbar-right" role="navigation">
            <ul id="nav" class="nav navbar-nav">
                <li>
                <?php if(isset($_SESSION['Username'])):?>
                  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown"><?php echo $_SESSION['Username'] ?>
                  <span class="caret"></span></button>
                  <ul class="dropdown-menu">
                    <li><a href="history.php" class="external">Booking History</a></li>
                    <li><a href="feedback.php" class="external"> Give Feedback</a></li>
                    <li><a href="logout.php" class="external">Logout</a></li>
                  </ul>
                  <?php else: ?>
                <li><a href ="login.php" class="external">Login</a></li>
                 <?php endif; ?>
                 </li>
            </ul>
          </nav>
          <!-- /main nav -->

        </div>
      </header>
    </div>
    <div>
      <br><br><br><br><br><br><br>
      <h3>Please Give Your feedback</h3><br>
      <form action="addFeedback.php" method="post">
        <h4>Select Hospital:</h4>
        <select name="lab_id" id="s1">
        <?php
          $sql = "Select `lab_id`,`lab_name` FROM `labs`";
          $labs_name_array = array();
          $lab_id_array = array();
          $query_to = mysqli_query($conn, $sql);
          while ($row = mysqli_fetch_assoc($query_to)) 
          {
            $labs_name_array[]=$row['lab_name'];
            $lab_id_array[]=$row['lab_id'];
            $lab_id = $row['lab_id'];
            $lab_name = $row['lab_name'];
            //echo "<option value='$lab_id'>".$lab_name."</option>";
          }
        foreach( $lab_id_array as $index => $lab_id_array) 
        {
          echo '<option value="' . $lab_id_array . '">' . $labs_name_array[$index] . '</option>';
        }
        ?>
        </select>
        <h4>Select Test:</h4>
        <select name="test_id">
        <?php
          $sql = "Select `test_id`,`test_name` FROM `test`";
          $query_to = mysqli_query($conn, $sql);
          while ($row = mysqli_fetch_assoc($query_to)) 
          {
            $test_name = $row['test_name'];
            $test_id = $row['test_id'];
            echo "<option value='$test_id'>".$test_name."</option>";
          }
        ?>
        </select>
        <h4>Give Your Score for hospitality</h4>
         <div class="radio">
              <label class="radio-inline">
              <input type="radio" value="1" name="hos_point">1</label>
              <label class="radio-inline">
              <input type="radio" value="2" name="hos_point">2</label>
              <label class="radio-inline">
              <input type="radio" value="3" name="hos_point">3</label>
              <label class="radio-inline">
              <input type="radio" value="4" name="hos_point">4</label>
              <label class="radio-inline">
              <input type="radio" value="5" name="hos_point">5</label> 
          </div>
          <h4>Give Your Score for facilities</h4>
           <div class="radio">
                <label class="radio-inline">
                <input type="radio" value="1" name="fac_point">1</label>
                <label class="radio-inline">
                <input type="radio" value="2" name="fac_point">2</label>
                <label class="radio-inline">
                <input type="radio" value="3" name="fac_point">3</label>
                <label class="radio-inline">
                <input type="radio" value="4" name="fac_point">4</label>
                <label class="radio-inline">
                <input type="radio" value="5" name="fac_point">5</label> 
            </div>
          <h4>Overall Score:</h4>
          <div class="radio">
              <label class="radio-inline">
              <input type="radio" value="1" name="ov_point">1</label>
              <label class="radio-inline">
              <input type="radio" value="2" name="ov_point">2</label>
              <label class="radio-inline">
              <input type="radio" value="3" name="ov_point">3</label>
              <label class="radio-inline">
              <input type="radio" value="4" name="ov_point">4</label>
              <label class="radio-inline">
              <input type="radio" value="5" name="ov_point">5</label> 
          </div>
          <h4>Give Your Comments</h4>
          <textarea rows="4" cols="50" name="comment"></textarea>
          <input type="submit" name="Submit">
      </form>
      
</div>
</body>
</html>
