  <?php include 'connect.php';
  if (session_status() == PHP_SESSION_NONE) {
    session_start();
    } 
  ?> 
  <!DOCTYPE html>
  <html lang="en" class="no-js"> 


  <html>
  <head>
    <title>Results</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <!-- Search -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/main.css">
    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script type="text/javascript" src="js/moment.js"></script>
    <script type="text/javascript" src="js/collapse.js"></script>
    <script type="text/javascript" src="js/transition.js"></script>
    <script type="text/javascript" src="bootstrap-datetimepicker.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
      .container { margin-top: 20px; }
      .mb20 { margin-bottom: 20px; } 

      hgroup { padding-left: 15px; border-bottom: 1px solid #ccc; }
      hgroup h1 { font: 500 normal 1.725em "Open Sans",Arial,Verdana,sans-serif; color: #000; margin-top: 0; line-height: 1.15; }
      hgroup h2.lead { font: normal normal 1.325em "Open Sans",Arial,Verdana,sans-serif; color: #000; margin: 0; padding-bottom: 10px; }
    </style>
  </head>
  <body>

    <div class="container">
      <header id="navigation" class="navbar-inverse navbar-fixed-top animated-header"  style="background-color: #003cb3" >
        <div class="container">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
              <a href="index.php"><img src="img/logo.png"></a>  
            <!-- /logo -->
          </div>

          <!-- main nav -->
          <nav class="collapse navbar-collapse navbar-right" role="navigation">
            <ul id="nav" class="nav navbar-nav">
               <li>
                <?php if(isset($_SESSION['Username'])):?>
                  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown"><?php echo $_SESSION['Username'] ?>
                  <span class="caret"></span></button>
                  <ul class="dropdown-menu">
                    <li><a href="history.php" class="external">Booking History</a></li>
                    <li><a href="feedback.php" class="external"> Give Feedback</a></li>
                    <li><a href="logout.php" class="external">Logout</a></li>
                  </ul>
                  <?php else: ?>
                <li><a href ="login.php" class="external">Login</a></li>
                 <?php endif; ?>
            </ul>
          </nav>
          <!-- /main nav -->

        </div>
      </header>
      <br><br><br><br><br><br><br>
        <table class="table table-striped">
          <thead>
            <tr>
              <td>Patient Name</td>
              <td>Test Name</td>
              <td>Lab</td>
              <td>Price</td>
              <td>Date</td>
              <td>Time</td>
            </tr>
          </thead>
          <tbody>
            <?php
              $user_name =  $_SESSION['Username'];

              $sql = "SELECT * FROM appointments WHERE customer_username = '$user_name'";
              $result = mysqli_query($conn,$sql);
              if (mysqli_num_rows($result) > 0) 
              {
                // output data of each row
                  while($row = mysqli_fetch_assoc($result)) 
                  {
                    $username = $row["customer_username"];
                    $customer_name = $row["customer_name"];
                    $customer_address = $row["customer_address"];
                    $test_name = $row["test_name"];
                    $test_price = $row["test_price"];
                    $test_hospital = $row["test_hospital"];
                    $test_date = $row["test_date"];
                    $test_time = $row["test_time"];


                    echo "<tr>".
                    "<td>".$customer_name."</td>".
                    "<td>".$test_name."</td>".
                    "<td>".$test_hospital."</td>".
                    "<td>".$test_price."</td>".
                    "<td>".$test_date."</td>".
                    "<td>".$test_time."</td>".
                    "</tr>";
                  }
              } 
              else
              {
                  echo "0 results";
              }
            ?>
          </tbody>
        </table>
    </body>
    </html>

