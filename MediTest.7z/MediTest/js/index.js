$('.search_button').click(function() {
if ($('.search_input').val() == '') 
    {
    $('.search_box').toggleClass("start");
    if (!$(this).is(":focus")){
      setTimeout(function(){
        $('.search_input').focus();
      }, 920);
    }
}
else {
  $('.search_box').addClass("finish");
}
});