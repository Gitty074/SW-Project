<?php include "connect.php"; $_SESSION = array();
unset($_SESSION['id']); session_destroy();header('Location:index.php'); ?>
<meta http-equiv="refresh" content="0;index.php">