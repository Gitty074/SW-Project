<?php
	require 'connect.php';
	if (session_status() == PHP_SESSION_NONE)
	{
        session_start();
    } 
	if($_SERVER["REQUEST_METHOD"] == "POST")
	{
		$user_name = $_SESSION['Username'];
		$customer_name = $_POST['name'];
		$customer_phone = $_POST['phone'];
		$customer_address = $_POST['address'];
		$customer_gender = $_POST['gender'];
		$customer_email = $_POST['email'];
		$test_name = $_SESSION['test_name'];
		$test_price = $_SESSION['test_price'];
		$test_date = $_SESSION['datepicker'];
		$test_time = $_SESSION['timepicker'];
		$lab_name = $_SESSION['lab_name'];

	}

	
	$addSQL = "INSERT INTO `appointments`(`customer_username`,`customer_name`,`customer_gender`, `customer_address`, `customer_phone`, `test_name`, `test_price`, `test_hospital`, `test_time`, `test_date`)
			VALUES ('$user_name','$customer_name','$customer_gender', '$customer_address','$customer_phone','$test_name',
			'$test_price','$lab_name','$test_time','$test_date')";
	if (mysqli_query($conn, $addSQL)) {
    echo "Appointment Information sent successfully.You will receive a message shortly";
    echo "<button onclick=\"window.location.href='../meditest/index.php'\">Continue</button>\n";
	} else
	 {
	    echo "Error adding to database: " . mysqli_error($conn);
	   // echo "<button onclick=\"window.location.href='../pages/admin.php'\">Continue</button>\n";
	 }
	 //session_unset();
	 mysqli_close($conn);
?>