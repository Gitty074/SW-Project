  <?php include 'connect.php'; 
    if (session_status() == PHP_SESSION_NONE) {
          session_start();}
          ?>
            
  <!DOCTYPE html>
  <html lang="en" class="no-js">
  <html>
  <head>
    <title>Results</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <!-- Search -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/main.css">
    <style>


      .container { margin-top: 20px; }
      .mb20 { margin-bottom: 20px; } 

      hgroup { padding-left: 15px; border-bottom: 1px solid #ccc; }
      hgroup h1 { font: 500 normal 1.725em "Open Sans",Arial,Verdana,sans-serif; color: #000; margin-top: 0; line-height: 1.15; }
      hgroup h2.lead { font: normal normal 1.325em "Open Sans",Arial,Verdana,sans-serif; color: #000; margin: 0; padding-bottom: 10px; }

      .search-result .thumbnail { border-radius: 0 !important; }
      .search-result:first-child { margin-top: 0 !important; }
      .search-result { margin-top: 20px; }
      .search-result .col-md-2 { border-right: 1px dotted #ccc; min-height: 140px; }
      .search-result ul { padding-left: 0 !important; list-style: none;  }
      .search-result ul li { font: 400 normal 1em "Open Sans",Arial,Verdana,sans-serif;  line-height: 30px; }
      .search-result ul li i { padding-right: 5px; }
      .search-result .col-md-7 { position: relative; }
      .search-result h3 { font: 500 normal .675em "Open Sans",Arial,Verdana,sans-serif; margin-top: 0 !important; margin-bottom: 10px !important; }
      .search-result h3 > a, .search-result i { color: #248dc1 !important; }
      .search-result p { font: normal normal 1.125em "Open Sans",Arial,Verdana,sans-serif; } 
      /*                .search-result span.plus { position: absolute; right: 0; top: 126px; }*/
      .meta-search li.plus a { background-color: #248dc1; color: white; text-decoration: none; padding: 5px 5px 3px 5px; }
      .meta-search li.plus a:hover { background-color: #414141; }
      .meta-search li.plus a i { color: #fff !important; }
      .meta-search li.border { display: block; width: 97%; margin: 0 15px; border-bottom: 1px dotted #ccc; }
    </style>
  </head>
  <body>

    <div class="container">
      <header id="navigation" class="navbar-inverse navbar-fixed-top animated-header"  style="background-color: #003cb3" >
        <div class="container">
          <div class="navbar-header">
            <!-- responsive nav button -->
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
              <a href="index.php"><img src="img/logo.png"></a>  
            <!-- /logo -->
          </div>

          <!-- main nav -->
          <nav class="collapse navbar-collapse navbar-right" role="navigation">
            <ul id="nav" class="nav navbar-nav">
                <li>
                <?php if(isset($_SESSION['Username'])):?>
                  <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown"><?php echo $_SESSION['Username'] ?>
                  <span class="caret"></span></button>
                  <ul class="dropdown-menu">
                    <li><a href="history.php" class="external">Booking History</a></li>
                  <li><a href="feedback.php" class="external"> Give Feedback</a></li>
                  <li><a href="logout.php" class="external">Logout</a></li>
                  </ul>
                  <?php else: ?>
                <li><a href ="login.php" class="external">Login</a></li>
                 <?php endif; ?>
            </ul>
          </nav>
          <!-- /main nav -->

        </div>
      </header>


      <br><br><br><br><br><br><br>
      <hgroup class="mb20">
        <h1>Search Results</h1>
        <?php
          if(isset($_POST['sort']))
          {
            $num = 0;
            $output = '';
            $selected_radio = $_POST['sort'];
            $searchq = $_POST['search'];
            $searchparam = $_POST['radio'];
            $searchq = preg_replace("#[^0-9a-zA-Z]#i", "", $searchq);
          }
          if(isset($selected_radio) && $selected_radio=='plth')
          {
            $sql_search = "SELECT * FROM test NATURAL JOIN testprice NATURAL JOIN labs
                          WHERE ". $searchparam ." LIKE '%" . $searchq . "%'"."ORDER BY test_price";
          }
          elseif (isset($selected_radio) && $selected_radio=='phtl')
          {
            $sql_search = "SELECT * FROM test NATURAL JOIN testprice NATURAL JOIN labs
                          WHERE ". $searchparam ." LIKE '%" . $searchq . "%'"."ORDER BY test_price DESC";
          }
          $query_to = mysqli_query($conn, $sql_search);
          $count = mysqli_num_rows($query_to);
          if ($count == 0)
            $output = '<br>No Results Found!!';
          else
           {
            while ($row = mysqli_fetch_assoc($query_to))
             {
              $num++;
             }
           }
           echo "<h2 class='lead'><strong class='text-primary'>".$num."</strong> results were found for the search for <strong class='text-primary'>".$searchq."</strong></h2>               </hgroup>";
                while ($row = mysqli_fetch_assoc($query_to))
                 {
                  $test_name = $row['test_name'];
                  $test_price = $row['test_price'];
                  $lab_name = $row['lab_name'];
                  $location = $row['lab_location'];
                  $lab_time = $row['Lab_time'];
                  $logo = $row['logo'];
                  $img_path = "img/logo/$logo";
                  $_POST['test_name'] = $test_name;
                  $_POST['test_price'] = $test_price;
                  $_POST['lab_name'] = $lab_name;
                  $_SESSION['test_name'] = $test_name;
                  $_SESSION['lab_name'] = $lab_name;
                  $_SESSION['test_price'] = $test_price;
                
                 ?>
            <form action="details.php?" method="post">
            <section class="col-xs-12 col-sm-6 col-md-12">
            <article class="search-result row" style="border-style: solid;
            border-color: #fff #fff #248dc1 #fff;">
            <div class="col-xs-12 col-sm-12 col-md-3">
              <img src= "<?php echo $img_path; ?>" alt="" />
            </div>
            <div class="col-xs-12 col-sm-12 col-md-4">
              <ul class="meta-search">
                <li><i class="fa fa-info" aria-hidden="true"></i> <span><?php echo $test_name;  ?></span></li>
                <li><i class="fa fa-map-marker" aria-hidden="true"></i> <span><?php echo $lab_name;  ?></span></li>
                <li><i class="fa fa-map-marker" aria-hidden="true"></i> <span><?php echo $location;?></span></li>
                <li><i class="fa fa-money" aria-hidden="true"></i> <span><?php echo $test_price;  ?></span> Taka</li>
                <li><i class="glyphicon glyphicon-time"></i> <span><?php echo $lab_time;?></span></li>

                <li><input type="submit" class="btn btn-info" value="Book Test"></li>
                </ul>
              </div>
              <span class="clearfix borda"></span>
            </article>
            <?php    
          }
          
          if (!empty($output))
            print("<br><p></p>$output");
          ?>
        </section>
        </form>
      </div>
    </body>
    </html>

