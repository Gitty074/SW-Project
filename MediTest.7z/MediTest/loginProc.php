<?php
	require 'connect.php';
	if(!empty($_SESSION['LoggedIn']) && !empty($_SESSION['username']))
	{
	    echo "<meta http-equiv='refresh' content='=2;index.php' />";
	}
	elseif(!empty($_POST['username']) && !empty($_POST['password']))
	{
		$username = $_POST['username'];
	    $password = $_POST['password'];
	    $sql =  "SELECT * FROM user_accounts WHERE user_name = '".$username."' AND user_password = '".$password."'";
	    $checklogin = mysqli_query($conn,$sql);
	     
	    if(mysqli_num_rows($checklogin) == 1)
	    {

	        $row = mysqli_fetch_assoc($checklogin);
	        $email = $row['user_email'];
	         
	        $_SESSION['Username'] = $username;
	        $_SESSION['EmailAddress'] = $email;
	        $_SESSION['UserID'] = $row['user_id'];
	        $_SESSION['LoggedIn'] = 1;
					         
	        echo "<h1>Success</h1>";
	        echo "<p>We are now redirecting you to the member area.</p>";
	        echo "<meta http-equiv='refresh' content='=2;index.php' />";
	    }
	    else
	    {
	        echo "<h1>Error</h1>";
	        echo "<p>Sorry, your account could not be found. Please <a href=\"login.php\">click here to try again</a>.</p>";
	    }
	}
	else
	{
	   
	}
	?>